package com.common;

public class Constants {
    public static final int XP = 250;
    public static final int XP_MULTIPLICATOR = 50;
    public static final int INITIAL_XP = 0;
    public static final int INITIAL_LEVEL = 0;
    public static final int XP_LEVEL_1 = 250;
    public static final int XP_LEVEL_2 = 300;
    public static final int XP_LEVEL_3 = 350;
    public static final int XP_LEVEL_4 = 400;
    public static final int PYROMANCER_HP = 500;
    public static final int KNIGHT_HP = 900;
    public static final int WIZARD_HP = 400;
    public static final int ROGUE_HP = 600;


}
