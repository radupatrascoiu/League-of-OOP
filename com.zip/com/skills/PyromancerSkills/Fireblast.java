package com.skills.PyromancerSkills;

import com.heroes.Knight;
import com.heroes.Pyromancer;
import com.heroes.Rogue;
import com.heroes.Wizard;
import com.skills.Skill;

public class Fireblast implements Skill {
    @Override
    public void visit(Pyromancer pyromancer) {

    }

    @Override
    public void visit(Knight knight) {

    }

    @Override
    public void visit(Wizard wizard) {

    }

    @Override
    public void visit(Rogue rogue) {

    }
}
