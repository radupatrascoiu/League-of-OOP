package common;

public class XPAngelConstants {
    private XPAngelConstants() {
    }
    public static final int XP_PYROMANCER = 50;
    public static final int XP_KNIGHT = 45;
    public static final int XP_WIZARD = 60;
    public static final int XP_ROGUE = 40;
}
