package com.main;

public class InitialPosition {
    private int x;
    private int y;

    public InitialPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public String toString() {
        return "InitialPosition{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
